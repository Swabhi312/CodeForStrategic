package com.strategicaccount.Controller;

import com.strategicaccount.AccountRepository;
import com.strategicaccount.Entity.AccountInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/account")
public class AccountController {

    @Autowired
    private AccountRepository accountRepository;
    @GetMapping("/getInformation/{id}")
    public AccountInfo getAccountDetails(@PathVariable int id){
        return accountRepository.getById(id);
    }

    @PostMapping("/addAccount")
    public AccountInfo getAccountDetails(@RequestBody AccountInfo accountInfo){
        return accountRepository.save(accountInfo);
    }
}

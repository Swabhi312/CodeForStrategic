package com.strategicaccount.Entity;


import jakarta.persistence.Column;
import jakarta.persistence.Id;

import jakarta.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
@Table(name = "AccountInfo")
public class AccountInfo {

    @Id
    @Column
    private Integer transactionId;

    @Column
    private String Name;

    @Column
    private String transDetails;


}
